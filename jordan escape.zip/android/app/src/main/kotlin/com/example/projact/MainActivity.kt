package com.example.projact

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
